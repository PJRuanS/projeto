package com.mycompany.mavenproject3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.WindowConstants;
public class Mavenproject3 extends JFrame {
    // Componentes Login
    private JTextField userLoginField;
    private JPasswordField passLoginField;
    private JButton btnLogin, btnVaiCadastro;

    // Componentes Cadastro
    private JTextField userCadastroField;
    private JPasswordField passCadastroField;
    private JButton btnCadastrar, btnVaiLogin;

    // Conexão MySQL
    private final String URL = "jdbc:mysql://localhost:3306/meu_banco?useTimezone=true&serverTimezone=UTC";
    private final String USER = "root";
    private final String PASS = "senac@2025";

    private CardLayout cardLayout = new CardLayout();
    private JPanel painelPrincipal = new JPanel(cardLayout);

    public Mavenproject3() {
        super("Login e Cadastro");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(350, 300);
        setLocationRelativeTo(null);

        painelPrincipal.add(criarPainelLogin(), "LOGIN");
        painelPrincipal.add(criarPainelCadastro(), "CADASTRO");

        add(painelPrincipal);
        cardLayout.show(painelPrincipal, "LOGIN");
    }

    private JPanel criarPainelLogin() {
        JPanel painel = new JPanel(new GridLayout(6, 2, 5, 5));
        painel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        painel.add(new JLabel("Usuário:"));
        userLoginField = new JTextField();
        painel.add(userLoginField);

        painel.add(new JLabel("Senha:"));
        passLoginField = new JPasswordField();
        painel.add(passLoginField);

        btnLogin = new JButton("Login");
        painel.add(btnLogin);

        btnVaiCadastro = new JButton("Cadastro");
        painel.add(btnVaiCadastro);

        JButton btnDeletar = new JButton("Deletar");
        painel.add(btnDeletar);

        JButton btnAlterarSenha = new JButton("Alterar Senha");
        painel.add(btnAlterarSenha);

        btnLogin.addActionListener(e -> fazerLogin());
        btnVaiCadastro.addActionListener(e -> cardLayout.show(painelPrincipal, "CADASTRO"));
        btnDeletar.addActionListener(e -> deletarUsuario());
        btnAlterarSenha.addActionListener(e -> alterarSenha());

        return painel;
    }

    private JPanel criarPainelCadastro() {
        JPanel painel = new JPanel(new GridLayout(4, 2, 5, 5));
        painel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        painel.add(new JLabel("Novo usuário:"));
        userCadastroField = new JTextField();
        painel.add(userCadastroField);

        painel.add(new JLabel("Nova senha:"));
        passCadastroField = new JPasswordField();
        painel.add(passCadastroField);

        btnCadastrar = new JButton("Cadastrar");
        painel.add(btnCadastrar);

        btnVaiLogin = new JButton("Voltar ao Login");
        painel.add(btnVaiLogin);

        btnCadastrar.addActionListener(e -> cadastrarUsuario());
        btnVaiLogin.addActionListener(e -> cardLayout.show(painelPrincipal, "LOGIN"));

        return painel;
    }

    private void fazerLogin() {
        String usuario = userLoginField.getText().trim();
        String senha = new String(passLoginField.getPassword());

        if (usuario.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha usuário e senha!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {
            String sql = "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, usuario);
            stmt.setString(2, senha);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Login efetuado com sucesso!");
                userLoginField.setText("");
                passLoginField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Usuário ou senha incorretos.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro no banco: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cadastrarUsuario() {
        String usuario = userCadastroField.getText().trim();
        String senha = new String(passCadastroField.getPassword());

        if (usuario.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha usuário e senha!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {
            String sql = "INSERT INTO usuarios (usuario, senha) VALUES (?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, usuario);
            stmt.setString(2, senha);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Usuário cadastrado com sucesso!");

            userCadastroField.setText("");
            passCadastroField.setText("");

            cardLayout.show(painelPrincipal, "LOGIN");
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1062) {
                JOptionPane.showMessageDialog(this, "Usuário já existe!", "Erro", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Erro no banco: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deletarUsuario() {
        String usuario = userLoginField.getText().trim();
        String senha = new String(passLoginField.getPassword());

        if (usuario.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Digite o nome do usuário e a senha para deletar a conta.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Tem certeza que deseja deletar o usuário '" + usuario + "'?",
            "Confirmar Deleção",
            JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {
            String sqlCheck = "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?";
            PreparedStatement stmtCheck = con.prepareStatement(sqlCheck);
            stmtCheck.setString(1, usuario);
            stmtCheck.setString(2, senha);

            ResultSet rs = stmtCheck.executeQuery();
            if (rs.next()) {
                String sqlDelete = "DELETE FROM usuarios WHERE usuario = ?";
                PreparedStatement stmtDelete = con.prepareStatement(sqlDelete);
                stmtDelete.setString(1, usuario);

                int rowsAffected = stmtDelete.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Usuário deletado com sucesso.");
                    userLoginField.setText("");
                    passLoginField.setText("");
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao deletar usuário.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Usuário ou senha incorretos.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void alterarSenha() {
        String usuario = userLoginField.getText().trim();
        String senhaAtual = new String(passLoginField.getPassword());

        if (usuario.isEmpty() || senhaAtual.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o usuário e a senha atual.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String novaSenha = JOptionPane.showInputDialog(this, "Digite a nova senha:");
        if (novaSenha == null || novaSenha.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nova senha não pode ser vazia.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {
            String sqlCheck = "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?";
            PreparedStatement stmtCheck = con.prepareStatement(sqlCheck);
            stmtCheck.setString(1, usuario);
            stmtCheck.setString(2, senhaAtual);

            ResultSet rs = stmtCheck.executeQuery();
            if (rs.next()) {
                String sqlUpdate = "UPDATE usuarios SET senha = ? WHERE usuario = ?";
                PreparedStatement stmtUpdate = con.prepareStatement(sqlUpdate);
                stmtUpdate.setString(1, novaSenha);
                stmtUpdate.setString(2, usuario);

                int updated = stmtUpdate.executeUpdate();
                if (updated > 0) {
                    JOptionPane.showMessageDialog(this, "Senha atualizada com sucesso.");
                    passLoginField.setText("");
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao atualizar a senha.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Usuário ou senha atual incorretos.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro no banco: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver não encontrado.");
        }

        SwingUtilities.invokeLater(() -> {
            new Mavenproject3().setVisible(true);
        });
    }
}
    