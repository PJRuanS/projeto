drop database meu_banco;
CREATE DATABASE meu_banco;
USE meu_banco;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL unique,
    senha VARCHAR(50) NOT NULL
);
select *from usuarios;